package es.api.services;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import javax.net.ssl.HttpsURLConnection;
import javax.ws.rs.BeanParam;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.client.Entity;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import es.api.modelo.Libro;
import SQL.Conexion;

@Path("/users")
public class ServicioUsers {

	
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public Response get() {
		try {
			Libro obLibro= new Libro();
			Conexion obConexion = new Conexion();
			Connection con=obConexion.getConexion();
			CallableStatement miSentencia=con.prepareCall("{call sp_libros(?, ?, ?)}");
			miSentencia.setString(2, "S");
			miSentencia.setString(3, obLibro.getNombre());
			return Response.ok(miSentencia).build();
		}catch(Exception e) {
			return Response.serverError().build();
		}
	}

	/**
	 * URL: http://localhost:8080/API_REST_WS-RS/api/users/createUser Parameters in
	 * Postman: {"name":"Rosa3333","username":"Marfi3333l"}
	 * 
	 * @param Libro
	 * @return Response list NOTA: Si no existe el constructor vac�o de User, da un
	 *         error y el userRequest viene null.
	 */
	@POST
	@Path("/createLibro")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public Response createLibro(Libro userRequest) {
		try {
			Libro obLibro= new Libro();
			Conexion obConexion = new Conexion();
			Connection con=obConexion.getConexion();
			CallableStatement miSentencia=con.prepareCall("{call sp_libros(?, ?, ?, ?, ?, ?, ?, ?)}");
			miSentencia.setString(1, obLibro.getCodigo());
			miSentencia.setString(2, "I");
			miSentencia.setString(3, obLibro.getNombre());
			miSentencia.setString(4, obLibro.getDescripcion());
			miSentencia.setString(5, obLibro.getAutor());
			miSentencia.setDate(6, (Date) obLibro.getFechaPublicacion());
			miSentencia.setInt(7, obLibro.getNumeroEjemplares());
			miSentencia.setFloat(8, obLibro.getCosto());
			
			return Response.ok(miSentencia).build();
		}catch(Exception e) {
			return Response.serverError().build();
		}

	}
	@PUT
	@Path("/updateLibro")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public Response updateLibro(Libro libroUpdate) {
		try {
			Libro obLibro= new Libro();
			Conexion obConexion = new Conexion();
			Connection con=obConexion.getConexion();
			CallableStatement miSentencia=con.prepareCall("{call sp_libros(?, ?, ?, ?, ?, ?, ?, ?)}");
			miSentencia.setString(1, obLibro.getCodigo());
			miSentencia.setString(2, "U");
			miSentencia.setString(3, obLibro.getNombre());
			miSentencia.setString(4, obLibro.getDescripcion());
			miSentencia.setString(5, obLibro.getAutor());
			miSentencia.setDate(6, (Date) obLibro.getFechaPublicacion());
			miSentencia.setInt(7, obLibro.getNumeroEjemplares());
			miSentencia.setFloat(8, obLibro.getCosto());
			
			return Response.ok(miSentencia).build();
		}catch(Exception e) {
			return Response.serverError().build();
		}
	}

	/**
	 * URL: http://localhost:8080/API_REST_WS-RS/api/users/deleteUser/Rosa
	 * 
	 * @param Libro
	 * @return Response
	 */
	@DELETE
	@Path("/deleteLibro/{codigo}")
	@Produces(MediaType.APPLICATION_JSON)
	public Response deleteUser(@PathParam("codigo") String codigo) {
		try {
			Libro obLibro= new Libro();
			Conexion obConexion = new Conexion();
			Connection con=obConexion.getConexion();
			CallableStatement miSentencia=con.prepareCall("{call sp_libros(?, ?)}");
			miSentencia.setString(1, codigo);
			miSentencia.setString(2, "D");
			return Response.ok(miSentencia).build();
		}catch(Exception e) {
			return Response.serverError().build();
		}
	}

}