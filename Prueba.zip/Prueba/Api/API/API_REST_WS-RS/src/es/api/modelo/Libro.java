package es.api.modelo;

import java.io.Serializable;
import java.util.Date;

public class Libro implements Serializable {

	private static final long serialVersionUID = 1L;

	public String l_codigo;
	
	public String l__nombre_libro;
	
	public String l_descripcion;
	
	public String l_autor;
	
	public Date l_fechas_publicacion;
	
	public int l_numero_ejemplares;

	public float l_costo;

	public Libro() {
		super();
	}
	
	public Libro(String l_codigo, String l__nombre_libro, String l_descripcion ,String l_autor, Date l_fechas_publicacion, int l_numero_ejemplares, float l_costo) {
		super();
		this.l_codigo = l_codigo;
		this.l__nombre_libro = l__nombre_libro;
		this.l_descripcion = l_descripcion;
		this.l_autor = l_autor;
		this.l_fechas_publicacion = l_fechas_publicacion;
		this.l_numero_ejemplares = l_numero_ejemplares;
		this.l_costo = l_costo;
	}

	public String getCodigo() {
		return l_codigo;
	}

	public void setCodigo(String l_codigo) {
		this.l_codigo = l_codigo;
	}
	
	public String getNombre() {
		return l__nombre_libro;
	}

	public void setNombre(String l__nombre_libro) {
		this.l__nombre_libro = l__nombre_libro;
	}

	public String getDescripcion() {
		return l_descripcion;
	}

	public void setDescripcion(String l_descripcion) {
		this.l_descripcion = l_descripcion;
	}
	public String getAutor() {
		return l_autor;
	}

	public void setAutor(String l_autor) {
		this.l_autor = l_autor;
	}
	public Date getFechaPublicacion() {
		return l_fechas_publicacion;
	}

	public void setFechaPublicacion(Date l_fechas_publicacion) {
		this.l_fechas_publicacion = l_fechas_publicacion;
	}
	
	public int getNumeroEjemplares() {
		return l_numero_ejemplares;
	}

	public void setNumeroEjemplares(int l_numero_ejemplares) {
		this.l_numero_ejemplares = l_numero_ejemplares;
	}
	public float getCosto() {
		return l_costo;
	}

	public void setCosto(float l_costo) {
		this.l_costo = l_costo;
	}

}