package es.api.services;

public @interface ApplicationPath {

}
