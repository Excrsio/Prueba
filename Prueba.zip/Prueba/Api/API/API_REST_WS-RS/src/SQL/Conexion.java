package SQL;

import java.sql.*;

public class Conexion {

	public Connection getConexion() {
		String conexionUrl="jdbc:sqlserver://localhost:1433;"
				+ "database=tempdb"
				+ "user="
				+ "password="
				+ "loginTimeout=30";
				try {
					Connection con = DriverManager.getConnection(conexionUrl);
					return con;
				}catch(SQLException ex) {
					return null;
				}
	}
	
}
