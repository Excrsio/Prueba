--SCRIPT CREACION TABLA
CREATE TABLE LIBRO(
l_codigo INT PRIMARY KEY,
l_nombre_libro  VARCHAR(150),
l_descripcion   VARCHAR(300),
l_autor         VARCHAR(150),
l_fechas_publicacion  DATETIME,
l_numero_ejemplares  INT,
l_costo	 FLOAT)




--STORE PROCEDURE
use tempdb
go

set ANSI_NULLS off
GO
set QUOTED_IDENTIFIER off
GO

if exists (select 1
             from sysobjects
            where name = 'sp_libros')
  drop proc sp_libros
go

create proc sp_libros(
	   @l_codigo   							INT 			=NULL,
       @l_operacion                         char(1),                -- Opcion con que se ejecuta el programa
       @l_nombre_libro                      VARCHAR(150)    = null, --Nombre del libro
       @l_descripcion                       VARCHAR(300)    = null, --Descripcion del libro
       @l_autor                           	VARCHAR(150)    = null, --Autor del libro
       @l_fechas_publicacion                DATETIME        = null, --Fechas publicacion del libro
       @l_numero_ejemplares                 int             = null, --Numero de ejemplares disponibles
       @l_costo		                        FLOAT           = null, --Costo del libro
       			  
)as




 
if @l_operacion = 'I'
begin
	INSERT INTO LIBRO				 (l_codigo,
	                                  l_nombre_libro, 
									  l_descripcion, 
									  l_autor, 
									  l_fechas_publicacion, 
									  l_numero_ejemplares, 
									  l_costo) 
							 VALUES (@l_codigo,
							         @l_nombre_libro,
									 @l_descripcion,
									 @l_autor,
									 @l_fechas_publicacion,
									 @l_numero_ejemplares,
									 @l_costo)  

END
 
 if @l_operacion = 'S'
begin
	SELECT * FROM LIBRO	where l_nombre_libro LIKE '%' + @l_nombre_libro + '%'

END
 
if @l_operacion = 'U'
 begin
	update LIBRO			 set    l_nombre_libro 			= isnull(@l_nombre_libro,l_nombre_libro), 
									l_descripcion 			= isnull(@l_descripcion,l_descripcion),
									l_autor 				= isnull(@l_autor, l_autor),
									l_fechas_publicacion 	= isnull(@l_fechas_publicacion, l_fechas_publicacion),
									l_numero_ejemplares		= isnull(@l_numero_ejemplares, l_numero_ejemplares),
									l_costo 				= isnull(@l_costo,l_costo)
									
	where l_codigo = @l_codigo
	
 END
 
 if @l_operacion = 'D'
begin
	DELETE  FROM LIBRO	where l_codigo = @l_codigo 

END
go


--EXECUTE DEL SP

EXECUTE sp_libros
@l_codigo               = 2,
@l_operacion            = 'I', 
@l_nombre_libro 		= 'Hola', 
@l_descripcion 			= 'Descripcion',
@l_autor 				= 'Juan' , 
@l_fechas_publicacion 	= '02/01/2021', 
@l_numero_ejemplares	= 2, 
@l_costo 				= 213

EXECUTE sp_libros
@l_codigo               = 2,
@l_operacion            = 'U', 
@l_nombre_libro 		= 'Hla' 


EXECUTE sp_libros
@l_operacion            = 'S', 
@l_nombre_libro 		= 'Hl' 

EXECUTE sp_libros
@l_codigo               = 1,
@l_operacion            = 'D'